// interface ITodoCard
// {
//     todoName : string
//     todoDescription: string
// }

interface ITodo
{
    text: string
    id: string
    completed: boolean
}